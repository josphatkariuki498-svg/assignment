# RadioButtonDemo — Java Assignment 2

## What the program does
- Shows five radio buttons: Bird, Cat, Dog, Rabbit, and Pig.
- Allows only one pet to be selected at a time.
- Displays the selected pet in the display panel.
- Shows a message box each time a pet is selected.

## Requirements
- Java JDK 8 or later
- Any operating system that supports Java Swing

## Run the program
Open a terminal in this folder and run:

```bash
javac RadioButtonDemo.java
java RadioButtonDemo
```

On Windows PowerShell, use the same commands from the project folder.

## Upload to GitHub
1. Sign in at https://github.com and create a new repository, for example `Java-RadioButtonDemo`.
2. Upload `RadioButtonDemo.java` and `README.md` using **Add file → Upload files**, then commit the changes.
3. Copy the repository URL and submit it with your assignment.

Example URL format (replace with your own repository):
`https://github.com/YOUR-USERNAME/Java-RadioButtonDemo`

Note: this is an example format, not a live repository link. You must upload the files to your own GitHub account to get your real URL.
